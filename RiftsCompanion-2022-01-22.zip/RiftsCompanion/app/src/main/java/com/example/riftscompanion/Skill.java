package com.example.riftscompanion;

import android.widget.ArrayAdapter;

import java.io.Serializable;
import java.util.ArrayList;

/* Class defining character skills
 *
 */
public class Skill implements Serializable {

    /* Class Variables */
    private int skillID;
    private String skillName;
    private String skillDescription;
    private String skillCategory;
    private int skillBaseProficiency;
    private int skillProficiencyPerLevel;
    private int skillSecondaryBaseProficiency;
    private int skillSecondaryProficiencyPerLevel;
    private String skillPrerequisites;
    private String skillModifier;
    private int skillModifierValue;

    /* Class access functions */
    public int getSkillID() { return skillID; }
    public String getSkillName() { return skillName; }
    public String getSkillDescription() { return skillDescription; }
    public String getSkillCategory() { return skillCategory; }
    public int getSkillBaseProficiency() { return skillBaseProficiency; }
    public int getSkillProficiencyPerLevel() { return skillProficiencyPerLevel; }
    public int getSkillSecondaryBaseProficiency() { return skillSecondaryBaseProficiency; }
    public int getSkillSecondaryProficiencyPerLevel() { return skillSecondaryProficiencyPerLevel; }
    public String getSkillPrerequisites() { return skillPrerequisites; }
    public String getSkillModifier() { return skillModifier; }
    public int getSkillModifierValue() { return skillModifierValue; }

    /* Constructor for the Skill class */
    public Skill(int skillID, String skillName, String skillDescription, String skillCategory, int skillBaseProficiency, int skillProficiencyPerLevel,
                 int skillSecondaryBaseProficiency, int skillSecondaryProficiencyPerLevel, String skillPrerequisites, String skillModifier,
                 int skillModifierValue) {

    }
}
