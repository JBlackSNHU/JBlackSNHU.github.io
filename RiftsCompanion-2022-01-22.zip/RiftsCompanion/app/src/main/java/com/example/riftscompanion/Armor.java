package com.example.riftscompanion;

import java.io.Serializable;

public class Armor implements Serializable {

    private int armorID;
    private String armorName;
    private String armorManufacturer;
    private String armorHelmetDamageCapacity;
    private String armorMainBodyDamageCapacity;
    private String armorArmsDamageCapacity;
    private String armorLegsDamageCapacity;
    private String armorMobility;
    private String armorMarketCost;
    private String armorAdditionalNotes;
    private String armorSource;

    public int getArmorID;
    public String getArmorName() {return armorName;}
    public String getArmorManufacturer() {return armorManufacturer;}
    public String getArmorHelmetDamageCapacity() {return armorHelmetDamageCapacity;}
    public String getArmorMainBodyDamageCapacity() {return armorMainBodyDamageCapacity;}
    public String getArmorArmsDamageCapacity() {return armorArmsDamageCapacity;}
    public String getArmorLegsDamageCapacity() {return armorLegsDamageCapacity;}
    public String getArmorMobility() {return armorMobility;}
    public String getArmorMarketCost() {return armorMarketCost;}
    public String getArmorAdditionalNotes() {return armorAdditionalNotes;}
    public String getArmorSource() {return armorSource;}

    public Armor (int armorID, String armorName, String armorManufacturer, String armorHelmetDamageCapacity,
                  String armorMainBodyDamageCapacity, String armorArmsDamageCapacity, String armorLegsDamageCapacity,
                  String armorMobility, String armorMarketCost, String armorAdditionalNotes, String armorSource) {
        this.armorID = armorID;
        this.armorName = armorName;
        this.armorManufacturer = armorManufacturer;
        this.armorHelmetDamageCapacity = armorHelmetDamageCapacity;
        this.armorMainBodyDamageCapacity = armorMainBodyDamageCapacity;
        this.armorArmsDamageCapacity = armorArmsDamageCapacity;
        this.armorLegsDamageCapacity = armorLegsDamageCapacity;
        this.armorMobility = armorMobility;
        this.armorMarketCost = armorMarketCost;
        this.armorAdditionalNotes = armorAdditionalNotes;
        this.armorSource = armorSource;
    }
}
