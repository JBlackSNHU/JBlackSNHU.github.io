package com.example.riftscompanion;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.Random;


public class PlayerCharacterAttributesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_character_attributes);
    }

    /* Uses the Java Math.Random class to
     * generate the random attribute rolls for each
     * attribute that needs to be assigned to the character
     */
    private void GenerateAttributeRolls() {

        int[] randomRolls = new int[8];
        int min = 1;
        int max = 6;
        for (int i = 0; i < 8; i++) {
            int rollOne, rollTwo, rollThree;
            rollOne = (int)(Math.random()*(max-min+1)+min);
            rollTwo = (int)(Math.random()*(max-min+1)+min);
            rollThree = (int)(Math.random()*(max-min+1)+min);
            int totalRoll = rollOne + rollTwo + rollThree;
            // If the total is less than 16 (average) then this value is assigned
            if (totalRoll < 16) {
                randomRolls[i] = totalRoll;
            }
            // If the total is 16, 17, or 18 (gte 16) then we add an additional roll since the attribute is exceptional
            else {
                randomRolls[i] = totalRoll + (int)(Math.random()*(max-min+1)+min);
            }
        }
    }
}