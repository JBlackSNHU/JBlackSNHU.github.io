package com.example.riftscompanion;

import java.io.Serializable;

public class Weapon implements Serializable {

    private int weaponID;
    private String weaponName;
    private String weaponManufacturer;
    private String weaponDescription;
    private String weaponWeight;
    private String weaponRange;
    private String weaponRateOfFire;
    private String weaponPayload;
    private String weaponDamageMDC;
    private String weaponDamageSDC;
    private String weaponMarketCost;

    public int getWeaponID() {return weaponID;}
    public String getWeaponName() {return weaponName;}
    public String getWeaponManufacturer() {return weaponManufacturer;}
    public String getWeaponDescription() {return weaponDescription;}
    public String getWeaponWeight() {return weaponWeight;}
    public String getWeaponRange() {return weaponRange;}
    public String getWeaponRateOfFire() {return weaponRateOfFire;}
    public String getWeaponPayload() {return weaponPayload;}
    public String getWeaponDamageMDC() {return weaponDamageMDC;}
    public String getWeaponDamageSDC() {return weaponDamageSDC;}
    public String getWeaponMarketCost() {return weaponMarketCost;}


    public Weapon(int weaponID, String weaponName, String weaponManufacturer, String weaponDescription, String weaponWeight, String weaponRange,
                  String weaponRateOfFire, String weaponPayload, String weaponDamageMDC, String weaponDamageSDC, String weaponMarketCost) {
        this.weaponID = weaponID;
        this.weaponName = weaponName;
        this.weaponManufacturer = weaponManufacturer;
        this.weaponDescription = weaponDescription;
        this.weaponWeight = weaponWeight;
        this.weaponRange = weaponRange;
        this.weaponRateOfFire = weaponRateOfFire;
        this.weaponPayload = weaponPayload;
        this.weaponDamageMDC = weaponDamageMDC;
        this.weaponDamageSDC = weaponDamageSDC;
        this.weaponMarketCost = weaponMarketCost;
    }
}
