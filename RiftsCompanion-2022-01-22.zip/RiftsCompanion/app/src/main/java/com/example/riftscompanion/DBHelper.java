package com.example.riftscompanion;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;


public class DBHelper extends SQLiteOpenHelper {

    /* DB NAME AND VERSION */
    private static final String DB_NAME="RiftsCompanionDatabase";
    private static final int DB_VERSION = 1;

    /* TABLE NAMES */
    private static final String PLAYER_CHARACTER_TABLE_NAME = "tbPlayerCharacters";
    private static final String SKILL_TABLE_NAME = "tbCharacterSkills";


    /* PLAYER CHARACTER TABLE COLUMN NAMES */
    /* JBLACK: Player Character shortened to PC for brevity */
    private static final String PC_ID_COL = "pcID";
    private static final String PC_NAME_COL = "pcName";



    /* SKILLS TABLE COLUMN NAMES */
    private static final String SKILL_ID_COL = "skillId";
    private static final String SKILL_NAME_COL = "skillName";
    private static final String SKILL_DESCRIPTION_COL = "skillDescription";
    private static final String SKILL_BASE_PROFICIENCY_COL = "skillBaseProficiency";
    private static final String SKILL_PROFICIENCY_PER_LEVEL_COL = "skillProficiencyPerLevel";
    private static final String SKILL_SECONDARY_BASE_PROFICIENCY_COL = "skillSecondaryBaseProficiency";
    private static final String SKILL_SECONDARY_PROFICIENCY_PER_LEVEL_COL = "skillSecondaryProficiencyPerLevel";
    private static final String SKILL_PREREQUISITES_COL = "skillPrerequisites";
    private static final String SKILL_MODIFIER_COL = "skillModifier";
    private static final String SKILL_MODIFIER_VALUE_COL = "skillModifierValue";



    public DBHelper(Context context) {super(context, DB_NAME, null, DB_VERSION);}

    /* Required to extend SQLiteOpenHelper */
    @Override
    public void onCreate(SQLiteDatabase db) {
        /* Check to see if the skills table exists */
        String checkSkillTableExistsQuery = "SELECT DISTINCT tbl_name FROM sqlite_master WHERE tbl_name = '" + SKILL_TABLE_NAME + "'";
        Cursor cursor = db.rawQuery(checkSkillTableExistsQuery, null);
        if (cursor != null) {
            if (cursor.getCount() > 0) {
                createAndPopulateSkillsTable(db);
            }
        }


        /* Create/Populate skills table if it does not exist */






    }

    /* Required onUpgrade() method to extend SQLiteOpenHelper */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){

    }

    /* This method will create and populate the tbCharacterSkills table
     * Because this is a static table, skills will only be read from the table
     * after this initial input
     */
    public void createAndPopulateSkillsTable(SQLiteDatabase db) {

        /* TABLE CREATION */
        /* Creating the SQL query that will create the CharacterSkills table if it does not already exist */
        String skillTableCreateQuery = "CREATE TABLE IF NOT EXISTS " + SKILL_TABLE_NAME + " ("
                + SKILL_ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + SKILL_NAME_COL + " TEXT, "
                + SKILL_DESCRIPTION_COL + " TEXT, "
                + SKILL_BASE_PROFICIENCY_COL + " INT, "
                + SKILL_PROFICIENCY_PER_LEVEL_COL + " INT, "
                + SKILL_SECONDARY_BASE_PROFICIENCY_COL + "INT, "
                + SKILL_SECONDARY_PROFICIENCY_PER_LEVEL_COL + "INT, "
                + SKILL_PREREQUISITES_COL + " TEXT, "
                + SKILL_MODIFIER_COL + " TEXT, "
                + SKILL_MODIFIER_VALUE_COL + " INT)";

        db.execSQL(skillTableCreateQuery);

        for (int i = 0; i < CreateSkillsList().size(); i++) {

        }



    }

    private ArrayList<Skill> CreateSkillsList() {
        /* CREATE ARRAY OF SKILLS */
        ArrayList<Skill> skillsList = new ArrayList<>();

        /*************************************************************************
         All skills initialized here have a skillID value of 0 because it has not
         * yet been assigned in the database. All integer values are also assigned 0
         * if they do not have a value in the rules (e.g. no secondary base proficiency).
         *************************************************************************/

        //region "Cryptography"
        skillsList.add(new Skill(0,
                "Cryptography",
                "Skill in recognizing, designing, and cracking secret\n" +
                "codes and messages. The character must study the code for two\n" +
                "hours to attempt to break it successfully. A failed roll means the\n" +
                "individual must study the code for an additional two hours before\n" +
                "he can try to break it again. The character may attempt to break the\n" +
                "code sooner, after only 10 minutes of study, but suffers a penalty\n" +
                "of - 30%.",
                "Communications",
                25,
                5,
                0,
                0,
                "Literacy",
                null,
                0));
        //endregion
        //region "Laser"
        skillsList.add(new Skill(0,
                "Laser",
                "This skill provides the character with an in depth knowledge\n" +
                "of sophistaced laser communication systems and fiber optic communications.",
                "Communications",
                30,
                5,
                0,
                0,
                "Radio: Basic, Electrical Engineer, Computer Operation",
                null,
                0));
        //endregion
        //region "Optic Systems"
        skillsList.add(new Skill(0,
                "Optic Systems",
                "Provides expert training in the use of special optical\n" +
                        "enhancement equipment such as telescopic lenses, laser targeting,\n" +
                        "thermo-imagers, passive light intensifiers, infrared and ultraviolet\n" +
                        "systems, polarization, light filters, optical scanners, and related devices",
                "Communications",
                30,
                5,
                0,
                0,
                null,
                "T.V./Video",
                5));
        //endregion
        //region "Optic Systems"
        skillsList.add(new Skill(0,
                "Radio: Basic",
                "This is the rudimentary knowledge of the operation and maintenance of field radios and walkie-talkies, wire laying, installation, radio procedure, communication security and visual signs/communications, as well as Morse code. It does not include the ability to make repairs.",
                "Communications",
                45,
                5,
                0,
                0,
                null,
                null,
                0));
        //endregion
        //region "Radio: Scramblers"
        skillsList.add(new Skill(0,
                "Radio: Scramblers",
                "This is training in the use of electronic masking, scrambling and unscrambling equipment, and codes to help foil the detection, interception and interpretation of radio transmissions by the enemy.",
                "Communications",
                35,
                5,
                0,
                0,
                null,
                null,
                0));
        //endregion
        //region "Surveillance Systems"
        skillsList.add(new Skill(0,
                "Surveillance Systems",
                "",
                "Communications",
                30,
                5,
                0,
                0,
                "Electronics: Basic, Electrical Engineering, Computer Operation, Literacy",
                null,
                0));
        //endregion

        return skillsList;
    }
}
