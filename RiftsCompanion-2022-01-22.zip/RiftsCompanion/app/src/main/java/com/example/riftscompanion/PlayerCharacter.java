package com.example.riftscompanion;

import java.io.Serializable;
import java.util.ArrayList;

/* Class for player character definition
 * All variables will be pre-fixed with "pc" short for Player Character"
 */
public class PlayerCharacter implements Serializable {

    /* Class variables */
    private int pcID;
    private String pcPlayerName;
    private String pcName;
    private int pcLevel;
    private int pcExperience;
    private int pcIntelligenceQuotient;
    private int pcMentalEndurance;
    private int pcMentalAffinity;
    private int pcPhysicalStrength;
    private int pcPhysicalProwess;
    private int pcPhysicalEndurance;
    private int pcPhysicalBeauty;
    private int pcSpeed;
    private int pcInnerStrengthPoints;
    private int pcPotentialPsychicEnergy;
    private ArrayList<Skill> pcSkills;
    /* JBLACK - Commented for now to assist in limiting project scope. */
    //private ArrayList<String> pcItems;
    private ArrayList<Armor> pcArmor;
    private ArrayList<Weapon> pcWeapons;
    private String pcClass;




    /* PlayerCharacter class constructor */
    public PlayerCharacter() {};

}
